package com.service.company.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name = "super_admin")
public class SuperAdmin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
	private int id;
	@Column(name = "email_id")
	private String email;
	
	@Column(name = "password")
    private String password;
	
	@Column(name = "profile_photo")
    private String profilePhoto;
    

    @Column(name = "first_name")
    private String firstName;
    
    @Column(name = "last_name")
    private String lastName;
    
    @Column(name = "mobile_number")
    private String mobileNumber;
    
    @Column(name = "phone_number")
    private String phoneNumber;
    
    @Column(name = "is_active")
    private boolean active;
    
    
    private LocalDateTime createdOn;
    
    @Column(name = "created_by")
    private int createdBy;
    @Column(name = "last_modified_on")
    private LocalDateTime modifiedOn;
    
    @Column(name = "last_modified_by")
    private int modifiedBy;

	public SuperAdmin(int id, String email, String password, String profilePhoto, String firstName, String lastName,
			String mobileNumber, String phoneNumber, boolean active, LocalDateTime createdOn, int createdBy,
			LocalDateTime modifiedOn, int modifiedBy) {
		super();
		this.id = id;
		this.email = email;
		this.password = password;
		this.profilePhoto = profilePhoto;
		this.firstName = firstName;
		this.lastName = lastName;
		this.mobileNumber = mobileNumber;
		this.phoneNumber = phoneNumber;
		this.active = active;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}

	public SuperAdmin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProfilePhoto() {
		return profilePhoto;
	}

	public void setProfilePhoto(String profilePhoto) {
		this.profilePhoto = profilePhoto;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(LocalDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	@Override
	public String toString() {
		return "SuperAdmin [id=" + id + ", email=" + email + ", password=" + password + ", profilePhoto=" + profilePhoto
				+ ", firstName=" + firstName + ", lastName=" + lastName + ", mobileNumber=" + mobileNumber
				+ ", phoneNumber=" + phoneNumber + ", active=" + active + ", createdOn=" + createdOn + ", createdBy="
				+ createdBy + ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy + ", getId()=" + getId()
				+ ", getEmail()=" + getEmail() + ", getPassword()=" + getPassword() + ", getProfilePhoto()="
				+ getProfilePhoto() + ", getFirstName()=" + getFirstName() + ", getLastName()=" + getLastName()
				+ ", getMobileNumber()=" + getMobileNumber() + ", getPhoneNumber()=" + getPhoneNumber()
				+ ", isActive()=" + isActive() + ", getCreatedOn()=" + getCreatedOn() + ", getCreatedBy()="
				+ getCreatedBy() + ", getModifiedOn()=" + getModifiedOn() + ", getModifiedBy()=" + getModifiedBy()
				+ ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
				+ "]";
	}
	
    
    

}
