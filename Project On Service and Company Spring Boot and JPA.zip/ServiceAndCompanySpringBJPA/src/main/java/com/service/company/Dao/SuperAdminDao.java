package com.service.company.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.service.company.entities.SuperAdmin;

public interface SuperAdminDao extends JpaRepository<SuperAdmin,Integer>{
	
	

}
