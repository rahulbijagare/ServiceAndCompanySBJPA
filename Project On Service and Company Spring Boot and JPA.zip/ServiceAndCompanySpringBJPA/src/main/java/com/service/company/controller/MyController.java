package com.service.company.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.service.company.entities.SuperAdmin;
import com.superAdmin.service.SuperAdminService;

@RestController
public  class MyController {
	

	@Autowired
	private SuperAdminService superAdminService;
	private Object superAdmin;
	
	@GetMapping("/admin")
	public List<SuperAdmin> getSuperAdmin(){
		SuperAdmin superAdmin=new SuperAdmin();
		superAdmin.setId(superAdmin.getId());
		superAdmin.setEmail(superAdmin.getEmail());
		superAdmin.setPassword(superAdmin.getPassword());
		
		superAdmin.setProfilePhoto(superAdmin.getProfilePhoto());
		
		superAdmin.setFirstName(superAdmin.getFirstName());
		superAdmin.setLastName(superAdmin.getLastName());
		superAdmin.setMobileNumber(superAdmin.getMobileNumber());
		superAdmin.setPhoneNumber(superAdmin.getPhoneNumber());
		superAdmin.setActive(superAdmin.isActive());
		superAdmin.setCreatedOn(superAdmin.getCreatedOn());
		superAdmin.setCreatedBy(superAdmin.getCreatedBy());
		
		superAdmin.setModifiedOn(superAdmin.getModifiedOn());
		superAdmin.setModifiedBy(superAdmin.getModifiedBy());
	
		{
		
		return ((SuperAdminService) this.superAdmin).getSuperAdmin();
		
	 }
	}

	@PostMapping("/admin/create")
   public SuperAdmin addSuperAdmin(@RequestBody SuperAdmin superAdmin) {
		
		superAdmin.setEmail(superAdmin.getEmail());
		superAdmin.setPassword(superAdmin.getPassword());
		
		superAdmin.setProfilePhoto(superAdmin.getProfilePhoto());
		superAdmin.setFirstName(superAdmin.getFirstName());
		superAdmin.setLastName(superAdmin.getLastName());
		superAdmin.setMobileNumber(superAdmin.getMobileNumber());
		superAdmin.setPhoneNumber(superAdmin.getPhoneNumber());
		superAdmin.setActive(superAdmin.isActive());
		superAdmin.setCreatedOn(superAdmin.getCreatedOn());
		superAdmin.setCreatedBy(superAdmin.getCreatedBy());
		
		return this.superAdminService.addSuperAdmin(superAdmin);
	   
   }
	
	@PutMapping("/admin/update/{ID}")
	public SuperAdmin updateSuperAdmin(@RequestBody SuperAdmin superAdmin) {
		superAdmin.setPassword(superAdmin.getPassword());
		superAdmin.setProfilePhoto(superAdmin.getProfilePhoto());
		superAdmin.setFirstName(superAdmin.getFirstName());
		superAdmin.setLastName(superAdmin.getLastName());
		superAdmin.setMobileNumber(superAdmin.getMobileNumber());
		superAdmin.setPhoneNumber(superAdmin.getPhoneNumber());
		superAdmin.setModifiedOn(superAdmin.getModifiedOn());
		superAdmin.setModifiedBy(superAdmin.getModifiedBy());
		
		return this.superAdminService.updateSuperAdmin(superAdmin);
		
	}
	
	@DeleteMapping("/admin/delete/{ID}")
	
		public ResponseEntity<HttpStatus>deleteSuperAdmin(@PathVariable String superAdminId){
		SuperAdmin superAdmin=new SuperAdmin();
		superAdmin.setActive(superAdmin.isActive());
		superAdmin.setModifiedOn(superAdmin.getModifiedOn());
		superAdmin.setModifiedBy(superAdmin.getModifiedBy());
		
		
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR );
		}
	}


