package com.service.company;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceAndCompanySpringBjpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceAndCompanySpringBjpaApplication.class, args);
	}

}
