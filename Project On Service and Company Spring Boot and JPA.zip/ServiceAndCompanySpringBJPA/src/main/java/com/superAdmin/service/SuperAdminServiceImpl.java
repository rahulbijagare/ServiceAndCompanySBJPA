package com.superAdmin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.service.company.Dao.SuperAdminDao;
import com.service.company.entities.SuperAdmin;
@Service
public class SuperAdminServiceImpl implements SuperAdminService {
	
	@Autowired
	private SuperAdminDao superAdminDao ;
	
	 
	
	
	 public SuperAdminServiceImpl(){
		 
		 
		
	}

	@Override
	public List<SuperAdmin> getSuperAdmin() {
		// TODO Auto-generated method stub
		return superAdminDao.findAll();
	}

	@Override
	public SuperAdmin addSuperAdmin(SuperAdmin superAdmin) {
		// TODO Auto-generated method stub
		
		superAdminDao.save(superAdmin);
		
		return superAdmin;
	}

	@Override
	public SuperAdmin updateSuperAdmin(SuperAdmin superAdmin) {
		// TODO Auto-generated method stub
		superAdminDao.save(superAdmin);
		return superAdmin;
		
	}

	@Override
	public void deleteSuperAdmin(int parseInt) {
		// TODO Auto-generated method stub
		SuperAdmin entity = superAdminDao.getOne(parseInt);
		superAdminDao.deleteAll();
		
	}

	}


