package com.superAdmin.service;

import java.util.List;

import com.service.company.entities.SuperAdmin;

public interface SuperAdminService {
	
	public List<SuperAdmin> getSuperAdmin();
	public SuperAdmin addSuperAdmin(SuperAdmin superAdmin);
	
	public SuperAdmin updateSuperAdmin( SuperAdmin superAdmin);
	
	public void deleteSuperAdmin( int parseInt);
	
}
