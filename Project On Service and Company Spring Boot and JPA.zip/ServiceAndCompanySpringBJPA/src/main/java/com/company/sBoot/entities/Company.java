package com.company.sBoot.entities;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "company")
public class Company {

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id;
	 @Column(name = "name", unique = true, nullable = false)
	private String name;
	 @Column(name = "url", nullable = false)
	private String url;
	   @Column(name = "logo")
	private String logo;
	   @Column(name = "first_name", nullable = false)
	private String firstName;
	   @Column(name = "last_name", nullable = false)
	private String lastName;
	   @Column(name = "phone_number", nullable = false)
	private String phoneNumber;
	   @Column(name = "active", nullable = false)
	private boolean active;
	   @Column(name = "created_on", nullable = false)
	private LocalDateTime createdOn;
	   @Column(name = "created_by", nullable = false)
	private int createdBy;
	   @Column(name = "modified_on")
	 private LocalDateTime modifiedOn;
	   @Column(name = "modified_by")
	 private int modifiedBy;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public int getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(int createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(LocalDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public int getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(int modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Company(int id, String name, String url, String logo, String firstName, String lastName, String phoneNumber,
			boolean active, LocalDateTime createdOn, int createdBy, LocalDateTime modifiedOn, int modifiedBy) {
		super();
		this.id = id;
		this.name = name;
		this.url = url;
		this.logo = logo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.phoneNumber = phoneNumber;
		this.active = active;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}

	public Company() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Company [id=" + id + ", name=" + name + ", url=" + url + ", logo=" + logo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", phoneNumber=" + phoneNumber + ", active=" + active + ", createdOn="
				+ createdOn + ", createdBy=" + createdBy + ", modifiedOn=" + modifiedOn + ", modifiedBy=" + modifiedBy
				+ "]";
	}
	 
	
	
	
}
