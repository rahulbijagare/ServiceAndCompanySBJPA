package com.company.sBoot.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.sBoot.entities.Company;

public interface CompanyDao extends JpaRepository<Company,Integer> {

}
