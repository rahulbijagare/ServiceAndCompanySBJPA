package com.company.sBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.company.sBoot.Dao.CompanyDao;
import com.company.sBoot.entities.Company;

public class CompanyServiceImpl implements CompanyService {
	
	@Autowired
	private CompanyDao companyDao;
	
	public CompanyServiceImpl() {
		
	}
	
	@Override
	public List<Company> getCompany(){
		
		return companyDao.findAll();
		
	}
	@Override
	public Company addCompany (Company company) {
		// TODO Auto-generated method stub
		
		companyDao.save(company);
		
		return company;
		
		
}
	@Override
	public Company updateCompany(Company company) {
		// TODO Auto-generated method stub
		companyDao.save(company);
		return company;
		
	}

	@Override
	public void deleteCompany(int parseInt) {
		// TODO Auto-generated method stub
		Company entity = companyDao.getOne(parseInt);
		companyDao.deleteAll();
	}
	}
