package com.company.sBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.company.sBoot.entities.Company;
import com.company.sBoot.service.CompanyService;
import com.service.company.entities.SuperAdmin;
import com.superAdmin.service.SuperAdminService;

@RestController
public class MyCompanyController {
	
	
	
	@Autowired
	private CompanyService companyService;
	private Object company;
	
	@GetMapping("/admin")
	public List<Company> getCompany(){
		
		Company company=new Company();
		company.setId(company.getId());
		company.setName(company.getName());
		
		company.setUrl(company.getUrl());
		company.setLogo(company.getLogo());
		company.setFirstName(company.getFirstName());
		company.setLastName(company.getLastName());
		
		company.setPhoneNumber(company.getPhoneNumber());
		company.setActive(company.isActive());
		company.setCreatedOn(company.getCreatedOn());
		
		company.setCreatedBy(company.getCreatedBy());
		company.setModifiedOn(company.getModifiedOn());
		company.setModifiedBy(company.getModifiedBy());
		
		return ((CompanyService) this.company).getCompany();
	}


@PostMapping("/company/create")
public Company addCompany(@RequestBody Company company) {
	
	
	company.setName(company.getName());
	company.setUrl(company.getUrl());
	company.setLogo(company.getLogo());
	company.setFirstName(company.getFirstName());
	company.setLastName(company.getLastName());
	
	company.setPhoneNumber(company.getPhoneNumber());
	company.setActive(company.isActive());
	company.setCreatedOn(company.getCreatedOn());
	
	company.setCreatedBy(company.getCreatedBy());
	
	return this.companyService.addCompany(company);
	
	
	
}


@PutMapping("/admin/update/{ID}")
public Company updateCompany(@RequestBody Company company) {
	
	company.setUrl(company.getUrl());
	company.setLogo(company.getLogo());
	company.setFirstName(company.getFirstName());
	company.setLastName(company.getLastName());
	
	company.setPhoneNumber(company.getPhoneNumber());
	
	company.setModifiedOn(company.getModifiedOn());
	company.setModifiedBy(company.getModifiedBy());
	
	
	return this.companyService.updateCompany(company);
}

@DeleteMapping("/admin/delete/{ID}")
public ResponseEntity<HttpStatus>deleteCompany(@PathVariable String companyId){
	Company company=new Company();
	company.setActive(company.isActive());
	company.setModifiedOn(company.getModifiedOn());
	company.setModifiedBy(company.getModifiedBy());
	
	return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR );


}
}
