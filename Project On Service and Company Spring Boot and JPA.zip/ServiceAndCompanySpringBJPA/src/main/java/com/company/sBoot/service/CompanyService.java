package com.company.sBoot.service;

import java.util.List;

import com.company.sBoot.entities.Company;

public interface CompanyService {
	
	
	public List<Company> getCompany();
	public Company addCompany(Company company);
	
	public Company updateCompany(Company company);
	
	public void deleteCompany( int parseInt);

}
